(function calculatedFieldValue(current) {

	// Add your code here
	return '';  // return the calculated value

})(current);