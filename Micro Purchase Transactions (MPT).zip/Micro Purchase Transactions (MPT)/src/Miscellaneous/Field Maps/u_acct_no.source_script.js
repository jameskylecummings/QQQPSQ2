answer = (function transformEntry(source) {

	// Add your code here
	return ""; // return the value to be put into the target field

})(source);