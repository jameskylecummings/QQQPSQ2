(function executeRule(current, previous /*null when async*/ ) {

    var grInsOpeningBalance = new GlideRecord('x_561190_micro_p_0_fy_opening_balance');
    var canWrite = grInsOpeningBalance.canWrite(); // used to check if curent user has write rights
    grInsOpeningBalance.addQuery('fiscal_year_lookup', current.fiscal_yr_lookup);
    grInsOpeningBalance.addQuery('account_lookup', current.account_number_lookup);
    grInsOpeningBalance.addQuery('division_lookup', current.organization_ref);
    grInsOpeningBalance.query(); // query with select conditions specified by the three addQuery

    if (canWrite) {
        while (grInsOpeningBalance.next()) {	// use loop to update record(s) erturned by query		
            var current_final_cost_non_legacy = parseFloat(current.final_cost_non_legacy);
            var previous_remaining_balance = parseFloat(grInsOpeningBalance.getValue('remaining_balance'));
            var remaining_balance =  Math.round((previous_remaining_balance - current_final_cost_non_legacy) * 100)/100; //this will round specified dollar amounts to two-place decimal

            grInsOpeningBalance.setValue('remaining_balance', remaining_balance); // set remaining balance
            grInsOpeningBalance.update(); // performs update
        }
    }

})(current, previous);