function onChange(control, oldValue, newValue, isLoading, isTemplate) {
    if (isLoading || newValue === '') {
        return;
    }
    if (newValue) {
        var requestor_lookup = g_form.getReference('requestor_lookup', popApprovalRequestorLookupInfo);
    }

    function popApprovalRequestorLookupInfo(requestor_lookup) {
        //requestor_lookup is the name of the field, 
        //and hences is referenced with dot notation
        var reqestor_name = g_form.getValue('reqestor_name');

        if (reqestor_name == '') {
            g_form.setValue('reqestor_name', requestor_lookup.first_name + ' ' +
                requestor_lookup.last_name);
        }

    }
}